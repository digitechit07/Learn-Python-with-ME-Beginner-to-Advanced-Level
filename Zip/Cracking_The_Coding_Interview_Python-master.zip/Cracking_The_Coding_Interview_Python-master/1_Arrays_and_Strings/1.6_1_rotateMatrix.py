input = [[1,2], [3,4]]
print (zip(*input[::-1]))