a = 47
b = "47"
d = 474

print(a)
print(type(a))  # <class 'int'>
print(b)
print(type(b))  # <class 'str'>

c = int(b)  # Typecasting string to integer
print(c)
print(type(c))  # <class 'int'>

e = str(d)  # Typecasting integer to string
print(e)
print(type(e))  # <class 'str'>