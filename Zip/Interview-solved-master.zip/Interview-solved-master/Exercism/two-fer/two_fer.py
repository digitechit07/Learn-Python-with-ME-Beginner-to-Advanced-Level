#!/usr/bin/env python
#encoding=utf8


def two_fer(name=''):
       if name != '':
            f"One for {name}, one for me"
        else:
            f"One for you, one for me"
