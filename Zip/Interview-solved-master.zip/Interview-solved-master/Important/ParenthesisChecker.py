# implement a parenthesis checker

def ParaChecker(symbolString):
    pass


print(ParaChecker(input("")))
