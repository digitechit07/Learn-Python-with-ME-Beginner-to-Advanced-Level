Each file begins with a problem statement. The rest of the file is the solution.
