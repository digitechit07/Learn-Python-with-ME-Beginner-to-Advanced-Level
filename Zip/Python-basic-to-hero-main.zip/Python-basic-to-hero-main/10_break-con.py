for i in range(1,21):
    print(i)
    if i ==11:
        break #cancel the execution of this loop now

for i in range(1,21):
    if i == 10:
        continue #continue the loop for next iteration here itself
    print(i)


i = 3
if i == 32:
    pass #do nothing
print("End of program")