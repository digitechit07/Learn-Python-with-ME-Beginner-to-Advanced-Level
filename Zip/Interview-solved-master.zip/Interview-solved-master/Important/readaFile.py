
path = ''

total = 0
with open(path) as f:
    lines = f.read()

for line in lines:
    print(line)
