def SumOfN(n):
    return (n*(n+1)/2)

print (SumOfN(10))
