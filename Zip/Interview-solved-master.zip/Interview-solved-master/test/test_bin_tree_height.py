import sys
import os
sys.path.append(os.path.join(sys.path[0], '../TreesAndGraphs/'))
from bin_tree_height import unit_test

def test_bin_tree_height():
    unit_test()
