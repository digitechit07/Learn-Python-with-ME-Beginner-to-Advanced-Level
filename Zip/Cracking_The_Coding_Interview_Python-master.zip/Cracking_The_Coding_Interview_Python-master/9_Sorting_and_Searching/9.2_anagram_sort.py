fruits = ['apple','pplea','jack','kacj','orange']
sorted(fruits, key = lambda x: sorted(list(x)))