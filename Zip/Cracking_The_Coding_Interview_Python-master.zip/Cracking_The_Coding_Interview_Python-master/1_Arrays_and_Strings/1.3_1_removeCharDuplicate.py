def removeDuplicate(input):
	return "".join(set(input))
input = raw_input("Enter the String : ")
print (removeDuplicate(input))